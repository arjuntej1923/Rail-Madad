declare module 'jsonwebtoken';


